package com.highradius.servlets;

import com.highradius.implementation.InvoiceDao;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.Invoice;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private InvoiceDao invoiceDao;

    @Override
    public void init() throws ServletException {
        super.init();
        invoiceDao = new InvoiceDaoImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String invoiceNumber = request.getParameter("invoiceNumber");
        String customerName = request.getParameter("customerName");

        Invoice invoice = new Invoice(id, id, id, invoiceNumber, customerName, id, customerName, id, customerName, customerName, customerName, id, id, customerName, customerName, customerName, id, id, id);
        invoiceDao.insertInvoice(invoice);

        // Redirect or display success message
    }
}