package com.highradius.servlets;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.highradius.implementation.InvoiceDao;
import com.highradius.implementation.InvoiceDaoImpl;
import com.highradius.model.Invoice;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

public class DataLoadingServlet extends HttpServlet {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private InvoiceDao invoiceDao;

    public void init() {
        invoiceDao = new InvoiceDaoImpl();
    }
    
    private void addCorsHeaders(HttpServletResponse response,HttpServletRequest request) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "DELETE");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token, Origin");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Max-Age", "86400");
    }
    
 
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	String customerIdParam = request.getParameter("customer_id");

    	if (customerIdParam == null || customerIdParam.isEmpty()) {
    	    int page = Integer.parseInt(request.getParameter("page"));
    	    int pageSize = Integer.parseInt(request.getParameter("pageSize"));

    	    getInvoices(page, pageSize, response);
    	} else {
    		if (customerIdParam == null || customerIdParam.isEmpty()) {
        	    int page = Integer.parseInt(request.getParameter("page"));
        	    int pageSize = Integer.parseInt(request.getParameter("pageSize"));

        	    getInvoices(page, pageSize, response);
        	} else {
        	    if (customerIdParam.equals("null")) {

        	    } else {
        	        try {
        	            int pageNumber = Integer.parseInt(request.getParameter("page"));
        	            int pageSize = Integer.parseInt(request.getParameter("pageSize"));
        	            int customerId = Integer.parseInt(customerIdParam);

        	            getInvoicesByCustomer(customerId, pageNumber, pageSize, response);
        	        } catch (NumberFormatException e) {

        	        }
        	    }
        	}

    	}
    }

    protected void getInvoices(int pageNumber, int pageSize, HttpServletResponse response) throws ServletException, IOException {
        List<Invoice> allInvoices = invoiceDao.getInvoice(pageNumber, pageSize);
        Gson gson = new Gson();

        String json = gson.toJson(allInvoices);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
    }

    protected void getInvoicesByCustomer(int customerId, int page, int pageSize, HttpServletResponse response) throws ServletException, IOException {
        List<Invoice> invoices = invoiceDao.getInvoicesByCustomer(customerId, page, pageSize);
        Gson gson = new Gson();
        String json = gson.toJson(invoices);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
    	
    }
    protected void updateRecord(Integer slNo,String curr, int companyCode, String distro, HttpServletResponse response) throws ServletException, IOException  {
    	invoiceDao.updateInvoice(slNo,curr, companyCode, distro);
    	Gson gson = new Gson();
        String json = gson.toJson("record updated");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);
    	
    }
    

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	addCorsHeaders(response,request);
        String idsParam = request.getParameter("ids");
        
        if (idsParam != null && !idsParam.isEmpty()) {
            String[] idsArray = idsParam.split(",");
            int[] ids = new int[idsArray.length];
            for (int i = 0; i < idsArray.length; i++) {
                ids[i] = Integer.parseInt(idsArray[i]);
            }
            InvoiceDao invoiceDao = new InvoiceDaoImpl();
            invoiceDao.deleteInvoice(ids);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().println("Invoices deleted successfully");
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().println("No invoice IDs provided");
        }
    }
    
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        StringBuilder requestBody = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            requestBody.append(line);
        }
        reader.close();
        Gson gson = new Gson();
        String dataReceived = requestBody.toString();
        String modifiedString = dataReceived.replace(":", ",");
     // Remove curly brackets
        modifiedString = modifiedString.replace("{", "").replace("}", "");
        String[] array = modifiedString.split(",");
        for (int i = 0; i < array.length; i++) {
            array[i] = array[i].replace("\"", "");
        }
        System.out.println("Array length: " + array.length);
        int customerOrderId = Integer.parseInt(array[1]);
        int salesOrg = Integer.parseInt(array[3]);
        String distributionChannel = array[5];
        int customerNo = Integer.parseInt(array[7]);
        int companyCode = Integer.parseInt(array[9]);
        String orderCurrency = array[11];
        int amountInUSD = Integer.parseInt(array[13]);
        String orderCreationDate = array[15];
        System.out.println("Customer Order ID: " + customerOrderId);
        System.out.println("Sales Organization: " + salesOrg);
        System.out.println("Distribution Channel: " + distributionChannel);
        System.out.println("Customer Number: " + customerNo);
        System.out.println("Company Code: " + companyCode);
        System.out.println("Order Currency: " + orderCurrency);
        System.out.println("Amount in USD: " + amountInUSD);
        System.out.println("Order Creation Date: " + orderCreationDate);       
        InvoiceDao invoiceDao = new InvoiceDaoImpl();
        invoiceDao.createNewInvoice(customerOrderId, salesOrg, distributionChannel, customerNo, companyCode, orderCurrency, amountInUSD, orderCreationDate);
        
     
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("received");
    }
}
    
    
//    protected void getInvoicesByCustomer(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        int page = Integer.parseInt(request.getParameter("page"));
//        int pageSize = Integer.parseInt(request.getParameter("pageSize"));
//        int customerId = Integer.parseInt(request.getParameter("customerId"));
//
//        List<Invoice> invoices = invoiceDao.getInvoicesByCustomer(customerId, page, pageSize);
//        
//        System.out.println(customerId);
//        
//        Gson gson = new Gson();
//
//        String json = gson.toJson(invoices);
//
//        response.setContentType("application/json");
//        response.setCharacterEncoding("UTF-8");
//        response.getWriter().write(json);
//    }