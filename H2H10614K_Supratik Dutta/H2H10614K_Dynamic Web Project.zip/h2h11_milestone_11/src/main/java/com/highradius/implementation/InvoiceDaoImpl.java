package com.highradius.implementation;

import java.sql.SQLException;
import java.util.List;
import com.highradius.connection.DatabaseConnection;
import com.highradius.model.Invoice;

public class InvoiceDaoImpl implements InvoiceDao {
    private DatabaseConnection databaseConnection; // Add this variable

    public InvoiceDaoImpl() {
        this.databaseConnection = new DatabaseConnection(); // Initialize the databaseConnection variable
    }

    @Override
    public List<Invoice> getInvoice(int page, int pageSize) {
        return databaseConnection.getInvoices(page, pageSize); // Use the databaseConnection variable to access the getInvoices() method
    }

    @Override
    public void insertInvoice(Invoice invoice) {
        databaseConnection.addInvoice(invoice); // Use the databaseConnection variable to access the addInvoice() method
    }

    @Override
    public void updateInvoice(int sl_no,String curr, int company_code, String distribution_channel) {
    	databaseConnection.updateRecord(sl_no, curr, company_code, distribution_channel);
    	
		
        // Implement update logic if needed
    }

    @Override
    public void deleteInvoice(int[] id) {
         //Implement delete logic if needed
    	try {
            DatabaseConnection.deleteInvoices(id);
        } catch (SQLException e) {
            // Handle the exception or throw a custom exception
            e.printStackTrace();
        }
    }
    @Override
    public List<Invoice> getInvoicesByCustomer(int customerId, int page, int pageSize) {
        try {
            return databaseConnection.getInvoicesByCustomer(customerId, page, pageSize);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

	@Override
	 public void createNewInvoice(int getCustomerOrderId,int salesOrg,String distributionChannel,int customerNo,int companyCode,String orderCurrency,int amountInUSD,String orderCreationDate ) {
    	databaseConnection.createNewInvoice(getCustomerOrderId, salesOrg, distributionChannel, customerNo, companyCode, orderCurrency, amountInUSD, orderCreationDate);
    }
    
}
