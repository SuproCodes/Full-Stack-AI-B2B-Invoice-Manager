package com.highradius.implementation;

import com.highradius.model.Invoice;
import java.util.List;

public interface InvoiceDao {
    List<Invoice> getInvoice(int page, int pageSize);

    void insertInvoice(Invoice invoice);

    void updateInvoice(int sl_no ,String curr, int company_code, String distribution_channel);

    void deleteInvoice(int[] selectIds);

	List<Invoice> getInvoicesByCustomer(int customerId, int page, int pageSize);
	
	

	void createNewInvoice(int getCustomerOrderId, int salesOrg, String distributionChannel, int customerNo,
			int companyCode, String orderCurrency, int amountInUSD, String orderCreationDate);
    
}