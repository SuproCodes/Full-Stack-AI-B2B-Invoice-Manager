package com.highradius.model;

public class Invoice {
	private int Sl_no;
	private int customer_order_id;
	private int sales_org;
	private String distribution_channel;
	private String division;
	private String purchase_order_type;
	private int company_code;
	private String order_creation_date;
	private String order_creation_time;
	private String credit_control_area;
	private int sold_to_party;
	private double order_amount;
	private String requested_delivery_date;
	private String order_currency;
	private String credit_status;
	private int customer_number;
	private double amount_in_usd;
	private long unique_cust_id;
	private double released_credit_value;
	public Invoice(int sl_no, int customer_order_id, int sales_org, String distribution_channel, String division,//creating the parameterized constructor.
			double released_credit_value, String purchase_order_type, int company_code, String order_creation_date,
			String order_creation_time, String credit_control_area, int sold_to_party, double order_amount,
			String requested_delivery_date, String order_currency, String credit_status, int customer_number,
			double amount_in_usd, long unique_cust_id) {
		super();
		Sl_no = sl_no;
		this.customer_order_id = customer_order_id;
		this.sales_org = sales_org;
		this.distribution_channel = distribution_channel;
		this.division = division;
		this.released_credit_value = released_credit_value;
		this.purchase_order_type = purchase_order_type;
		this.company_code = company_code;
		this.order_creation_date = order_creation_date;
		this.order_creation_time = order_creation_time;
		this.credit_control_area = credit_control_area;
		this.sold_to_party = sold_to_party;
		this.order_amount = order_amount;
		this.requested_delivery_date = requested_delivery_date;
		this.order_currency = order_currency;
		this.credit_status = credit_status;
		this.customer_number = customer_number;
		this.amount_in_usd = amount_in_usd;
		this.unique_cust_id = unique_cust_id;
	}
	public int getSl_no() {//creating the getters and setters
		return Sl_no;
	}
	public int getCustomer_order_id() {
		return customer_order_id;
	}
	public int getSales_org() {
		return sales_org;
	}
	public String getDistribution_channel() {
		return distribution_channel;
	}
	public String getDivision() {
		return division;
	}
	public double getReleased_credit_value() {
		return released_credit_value;
	}
	public String getPurchase_order_type() {
		return purchase_order_type;
	}
	public int getCompany_code() {
		return company_code;
	}
	public String getOrder_creation_date() {
		return order_creation_date;
	}
	public String getOrder_creation_time() {
		return order_creation_time;
	}
	public String getCredit_control_area() {
		return credit_control_area;
	}
	public int getSold_to_party() {
		return sold_to_party;
	}
	public double getOrder_amount() {
		return order_amount;
	}
	public String getRequested_delivery_date() {
		return requested_delivery_date;
	}
	public String getOrder_currency() {
		return order_currency;
	}
	public String getCredit_status() {
		return credit_status;
	}
	public int getCustomer_number() {
		return customer_number;
	}
	public double getAmount_in_usd() {
		return amount_in_usd;
	}
	public long getUnique_cust_id() {
		return unique_cust_id;
	}
	public void setSl_no(int sl_no) {
		Sl_no = sl_no;
	}
	public void setCustomer_order_id(int customer_order_id) {
		this.customer_order_id = customer_order_id;
	}
	public void setSales_org(int sales_org) {
		this.sales_org = sales_org;
	}
	public void setDistribution_channel(String distribution_channel) {
		this.distribution_channel = distribution_channel;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public void setReleased_credit_value(double reeased_credit_value) {
		this.released_credit_value = reeased_credit_value;
	}
	public void setPurchase_order_type(String purchase_order_type) {
		this.purchase_order_type = purchase_order_type;
	}
	public void setCompany_code(int company_code) {
		this.company_code = company_code;
	}
	public void setOrder_creation_date(String order_creation_date) {
		this.order_creation_date = order_creation_date;
	}
	public void setOrder_creation_time(String order_creation_time) {
		this.order_creation_time = order_creation_time;
	}
	public void setCredit_control_area(String credit_control_srea) {
		this.credit_control_area = credit_control_srea;
	}
	public void setSold_to_party(int sold_to_party) {
		this.sold_to_party = sold_to_party;
	}
	public void setOrder_amount(double order_amount) {
		this.order_amount = order_amount;
	}
	public void setRequested_delivery_date(String requested_delivery_date) {
		this.requested_delivery_date = requested_delivery_date;
	}
	public void setOrder_currency(String order_currency) {
		this.order_currency = order_currency;
	}
	public void setCredit_status(String credit_status) {
		this.credit_status = credit_status;
	}
	public void setCustomer_number(int customer_number) {
		this.customer_number = customer_number;
	}
	public void setAmount_in_usd(double amount_in_usd) {
		this.amount_in_usd = amount_in_usd;
	}
	public void setUnique_customer_id(long unique_cust_id) {
		this.unique_cust_id = unique_cust_id;
	}

}
