package com.highradius.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.highradius.model.Invoice;

public class DatabaseConnection {
	private List<Invoice> invoices;
	private static final String DB_URL = "jdbc:mysql://localhost:3306/test";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Supratik_14";
	public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
	
    public DatabaseConnection() {
        this.invoices = new ArrayList<>();
    }
    public void addInvoice(Invoice invoice) {
        invoices.add(invoice);
    }
    public static void deleteInvoices(int[] selectedIds) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
            connection = getConnection();
            String sql = "DELETE FROM h2h_oap WHERE sl_no IN (";
            
            // Generate the placeholders for the selected IDs
            String placeholders = String.join(",", Collections.nCopies(selectedIds.length, "?"));
            
            // Append the placeholders to the SQL statement
            sql += placeholders + ")";
            
            statement = connection.prepareStatement(sql);
            
            // Set the selected IDs as parameters in the prepared statement
            for (int i = 0; i < selectedIds.length; i++) {
                statement.setInt(i + 1, selectedIds[i]);
            }
            
            // Execute the delete statement
            statement.executeUpdate();
            
            System.out.println("Invoices deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting invoices: " + e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }
    
    public void updateRecord(int slNo, String currency, int companyCode, String distributionChannel) {
        try (Connection connection = getConnection()) {
            String sql = "UPDATE h2h_oap SET order_currency = ?, company_code = ?, distribution_channel = ? WHERE sl_no = ?";
            
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, currency);
                statement.setInt(2, companyCode);
                statement.setString(3, distributionChannel);
                statement.setInt(4, slNo);
                
                System.out.println(statement.toString());
                
                int rowsAffected = statement.executeUpdate();
                
                if (rowsAffected > 0) {
                    System.out.println("Record updated successfully.");
                } else {
                    System.out.println("No record found with the specified sl_no.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    

    public List<Invoice> getInvoices(int page, int pageSize) {
        List<Invoice> invoices = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM h2h_oap LIMIT ? OFFSET ?";
            int offset = (page - 1) * pageSize;

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, pageSize);
                statement.setInt(2, offset);
                
                System.out.println("Executing SQL query: " + statement.toString());

                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        // Retrieve the invoice data and create Invoice objects
                        // ...
                    	int sl_no = resultSet.getInt("sl_no");
                    	int customer_order_id = resultSet.getInt("customer_order_id");
                    	int sales_org = resultSet.getInt("sales_org");
                    	String distribution_channel = resultSet.getString("distribution_channel");
                    	String division = resultSet.getString("division");
                    	double released_credit_value = resultSet.getDouble("released_credit_value");
                    	String purchase_order_type = resultSet.getString("purchase_order_type");
                    	int company_code = resultSet.getInt("company_code");
                    	String order_creation_date = resultSet.getString("order_creation_date");
                    	String order_creation_time = resultSet.getString("order_creation_time");
                    	String credit_control_area = resultSet.getString("credit_control_area");
                    	int sold_to_party = resultSet.getInt("sold_to_party");
                    	double order_amount = resultSet.getDouble("order_amount");
                    	String requested_delivery_date = resultSet.getString("requested_delivery_date");
                    	String order_currency = resultSet.getString("order_currency");
                    	String credit_status = resultSet.getString("credit_status");
                    	int customer_number = resultSet.getInt("customer_number");
                    	double amount_in_usd = resultSet.getDouble("amount_in_usd");
                    	long unique_cust_id = resultSet.getLong("unique_cust_id");

                        Invoice invoice = new Invoice(sl_no, customer_order_id, sales_org,distribution_channel,division,
                        		released_credit_value,purchase_order_type,company_code,order_creation_date,order_creation_time,
                        		credit_control_area,sold_to_party,order_amount,requested_delivery_date,order_currency,credit_status,
                        		customer_number,amount_in_usd,unique_cust_id);
                        invoices.add(invoice);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return invoices;
    }
    
    public List<Invoice> getInvoicesByCustomer(int customerId, int page, int pageSize) throws SQLException {
        List<Invoice> invoices = new ArrayList<>();

        // Calculate the offset for pagination
        int offset = (page - 1) * pageSize;

        // Prepare the SQL statement
        String sql = "SELECT * FROM h2h_oap WHERE customer_order_id = ? ";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set the customer ID parameter
            statement.setInt(1, customerId);

            // Set the offset and page size parameters
//            statement.setInt(2, offset);
//            statement.setInt(3, pageSize);
            
            
            System.out.println("Executing SQL query: " + statement.toString());

            // Execute the query
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    // Retrieve the invoice data from the result set
                	int sl_no = resultSet.getInt("sl_no");
                	int customer_order_id = resultSet.getInt("customer_order_id");
                	int sales_org = resultSet.getInt("sales_org");
                	String distribution_channel = resultSet.getString("distribution_channel");
                	String division = resultSet.getString("division");
                	double released_credit_value = resultSet.getDouble("released_credit_value");
                	String purchase_order_type = resultSet.getString("purchase_order_type");
                	int company_code = resultSet.getInt("company_code");
                	String order_creation_date = resultSet.getString("order_creation_date");
                	String order_creation_time = resultSet.getString("order_creation_time");
                	String credit_control_area = resultSet.getString("credit_control_area");
                	int sold_to_party = resultSet.getInt("sold_to_party");
                	double order_amount = resultSet.getDouble("order_amount");
                	String requested_delivery_date = resultSet.getString("requested_delivery_date");
                	String order_currency = resultSet.getString("order_currency");
                	String credit_status = resultSet.getString("credit_status");
                	int customer_number = resultSet.getInt("customer_number");
                	double amount_in_usd = resultSet.getDouble("amount_in_usd");
                	long unique_cust_id = resultSet.getLong("unique_cust_id");
                    // Retrieve other invoice fields as needed

                    // Create the Invoice object
                    Invoice invoice = new Invoice(sl_no, customer_order_id, sales_org,distribution_channel,division,
                    		released_credit_value,purchase_order_type,company_code,order_creation_date,order_creation_time,
                    		credit_control_area,sold_to_party,order_amount,requested_delivery_date,order_currency,credit_status,
                    		customer_number,amount_in_usd,unique_cust_id);
                    // Set other fields of the invoice object as needed

                    // Add the invoice to the list
                    invoices.add(invoice);
                }
            }
        }

        return invoices;
        
        
    }
    public void createNewInvoice(int getCustomerOrderId,int salesOrg,String distributionChannel,int customerNo,int companyCode,String orderCurrency,int amountInUSD,String orderCreationDate ) {
        
        try {
        	Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "INSERT INTO h2h_oap (customer_order_id, sales_org, distribution_channel, customer_number, company_code, order_currency, amount_in_usd, order_creation_date,division,released_credit_value,purchase_order_type,ORDER_CREATION_TIME,CREDIT_CONTROL_AREA,SOLD_TO_PARTY,ORDER_AMOUNT,REQUESTED_DELIVERY_DATE,CREDIT_STATUS,UNIQUE_CUST_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?,'North-Region',0,'X000','210010','SR02',756141537,500,'05-01-2022','NaN',12345678)";
            PreparedStatement statement = connection.prepareStatement(query);
        	
        	
        	 statement.setInt(1, getCustomerOrderId);
             statement.setInt(2, salesOrg);
             statement.setString(3, distributionChannel);
             statement.setInt(4, customerNo);
             statement.setInt(5, companyCode);
             statement.setString(6, orderCurrency);
             statement.setInt(7, amountInUSD);
             statement.setString(8, orderCreationDate);
             
             statement.executeUpdate();
             
             System.out.println("Executing SQL query: " + statement.toString());
        	
        	
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
}