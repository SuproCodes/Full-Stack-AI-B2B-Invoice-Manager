import './App.css';
// import InvoiceList from './components/InvoiceList';
import { render } from "react-dom";
import TabComponent from './components/MainTab';

function App() {
  return (
    <div className="App">
      {/* <InvoiceList/> */}
      <TabComponent/>
    </div>
  );
}

export default App;