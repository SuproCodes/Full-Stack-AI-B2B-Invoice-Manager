import React, { useEffect, useState } from 'react';
import axios from 'axios';
import logo from '../hrclogo.svg';
import logo1 from '../abclogo.svg';
import {
  Button,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Checkbox,
  Paper,
  Box,
  Pagination,
  TablePagination,
  CircularProgress,
  Snackbar,
  Alert,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';

const RecordsTable = () => {
  const [records, setRecords] = useState([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedIds, setSelectedIds] = useState([]);
  const [showToast, setShowToast] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [editedCurrency, setEditedCurrency] = useState('');
  const [editedCompanyCode, setEditedCompanyCode] = useState('');
  const [editedDistributionChannel, setEditedDistributionChannel] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [totalRecords, setTotalRecords] = React.useState(0);

  useEffect(() => {
    fetchData();
  }, [page, pageSize]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/h2h11_milestone_11/DataLoadingServlet?page=${page}&pageSize=${pageSize}&customerOrderId=${searchTerm}`);
      setRecords(response.data);
    } catch (error) {
      console.log('Error fetching data:', error);
    }
  };

  const handlePageChange = (event, value) => {
    setPage(value);
  };

  const handlePageSizeChange = (event) => {
    setPageSize(parseInt(event.target.value));
    setPage(1);
  };


  const handleSelect = (event, sl_no) => {
    if (event.target.checked) {
      setSelectedIds((prevSelectedIds) => [...prevSelectedIds, sl_no]);
    } else {
      setSelectedIds((prevSelectedIds) => prevSelectedIds.filter((id) => id !== sl_no));
    }
  };

  const handleDelete = async () => {
    try {
      setIsLoading(true);
      const url = `http://localhost:8080/h2h11_milestone_11/DataLoadingServlet?ids=${selectedIds.join(",")}`;
      await axios.delete(url);
      await fetchData();
      setSelectedIds([]);
      setShowToast(true);
    } catch (error) {
      console.log('Error deleting records:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToastClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setShowToast(false);
  };

  const handleSearch = async (event) => {
    event.preventDefault();
    try {
      await fetchData();
    } catch (error) {
      console.log('Error searching records:', error);
    }
  };

  const handleSearchInputChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleEdit = () => {
    if (selectedIds.length === 1) {
      const selectedRecord = records.find((record) => record.Sl_no === selectedIds[0]);
      if (selectedRecord) {
        setSelectedRecord(selectedRecord);
        setEditedCurrency(selectedRecord.order_currency);
        setEditedCompanyCode(selectedRecord.company_code);
        setEditedDistributionChannel(selectedRecord.distribution_channel);
        setEditDialogOpen(true);
      }
    }
  };
  const handleSaveEdit = async () => {
    try {
      setIsSavingEdit(true); // Start the saving operation
      const updatedRecord = {
        order_currency: editedCurrency,
        company_code: editedCompanyCode,
        distribution_channel: editedDistributionChannel,
      };
  
      // Update the URL and params accordingly based on your servlet's requirements
      const url = `http://localhost:8080/h2h11_milestone_11/DataLoadingServlet`;
      const params = {
        sl_no: selectedRecord.Sl_no,
        ...updatedRecord,
      };
  
      await axios.get(url, { params });
  
      setEditDialogOpen(false);
      await fetchData();
      setShowToast(true);
    } catch (error) {
      console.log('Error updating record:', error);
    } finally {
      // Delay the page reload for 2 seconds
      setTimeout(() => {
        setIsSavingEdit(false); // Stop the saving operation
        window.location.reload();
      }, 1000);
    }
  };
  
  const handleEditDialogClose = () => {
    setEditDialogOpen(false);
  };

  const handleCurrencyChange = (event) => {
    setEditedCurrency(event.target.value);
  };

  const handleCompanyCodeChange = (event) => {
    setEditedCompanyCode(event.target.value);
  };

  const handleDistributionChannelChange = (event) => {
    setEditedDistributionChannel(event.target.value);
  };

  const isSingleItemSelected = selectedIds.length === 1;

  return (
    <>
    <div class="header">
      <img src={logo} alt="HRCLogo" class="logo"/>
      <img src={logo1} alt="abcLogo" class="logo1"/>
    </div>
    <Box display="flex" justifyContent="flex-end" alignItems="center">
      <form onSubmit={handleSearch} style={{ display: 'flex',marginBottom: '1rem',backgroundColor:'white' }}>
        <TextField
          label="Search Customer ID"
          variant="outlined"
          value={searchTerm}
          onChange={handleSearchInputChange}
          // style={{ marginRight: '1rem' }}
        />
        <Button variant="contained" type="submit" style={{backgroundColor: '#8fd163',color:'black'}}>
          Search
        </Button>
      </form>
    </Box>

      <TableContainer component={Box} sx={{backgroundColor:'#666666', border:'6px solid #fc7500'}}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ color: 'white',textAlign:'center' }}></TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Sl No</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Customer Order ID</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Sales Org</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Distribution Channel</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Company Code</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Order Creation Date</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Order Currency</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Customer Number</TableCell>
              <TableCell sx={{ color: 'white',textAlign:'center' }}>Amount In USD</TableCell>




              {/* Add more table headers for other fields */}
            </TableRow>
          </TableHead>
          <TableBody>
            {records.map((record) => (
              <TableRow key={record.Sl_no}>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>
                <Checkbox
                    checked={selectedIds.includes(record.Sl_no)}
                    onChange={(event) => handleSelect(event, record.Sl_no)}
                    style={{ color: 'white' }}
                  />
                </TableCell>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.Sl_no}</TableCell>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.customer_order_id}</TableCell>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.sales_org}</TableCell>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.distribution_channel}</TableCell>
                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.company_code}</TableCell>

                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.order_creation_date}</TableCell>

                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.order_currency}</TableCell>

                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.customer_number}</TableCell>

                <TableCell sx={{ color: 'white',textAlign:'center' }}>{record.amount_in_usd}</TableCell>

                
                {/* Add more table cells for other fields */}
              </TableRow>
            ))}
          </TableBody>
          <Box sx={{display: 'flex', justifyContent: 'flex-end'}}>
       <div>
      <TablePagination  
        count={104858}
        page={page}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handlePageSizeChange}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={[5, 10, 25, 50]}
        style={{ position: 'absolute', right: 0 }}
      />

     
        {/* Page Size:
        <select value={pageSize} onChange={handlePageSizeChange}>
          <option value={10}>10</option>
          <option value={20}>20</option>
          <option value={50}>50</option>
        </select> */}
      </div>
      </Box>
        </Table>
      </TableContainer>
      <Box sx={{ display: 'flex', justifyContent: 'flex-start' }}>
      <Button
        variant="contained"
        color="primary"
        disabled={!isSingleItemSelected || isLoading}
        onClick={handleEdit}
        style={{ position: 'relative', marginTop: '1rem', marginRight: '1rem',backgroundColor:"#fc7500" }}
      >
        Edit
      </Button>

      <Button
        variant="contained"
        color="primary"
        disabled={selectedIds.length === 0 || isLoading}
        onClick={handleDelete}
        style={{ position: 'relative', marginTop: '1rem',backgroundColor:"#fc7500" }}
        
      >
        {isLoading && (
          <CircularProgress size={24} style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }} />
        )}
        Delete
      </Button>
      {/* <div className="Refresh-btn"> 
        <RefreshButton style={{ display: 'flex', padding: '1rem',backgroundColor:"#fc7500" }}/>
      </div> */}
      </Box>

      {/* <Pagination
        count={104858}
        page={page}
        onChange={handlePageChange}
        showFirstButton
        showLastButton
      /> */}
   

      <Snackbar open={showToast} autoHideDuration={3000} onClose={handleToastClose}>
        <Alert onClose={handleToastClose} severity="success" sx={{ width: '100%' }}>
          Operation completed successfully.
        </Alert>
      </Snackbar>

      <Dialog open={editDialogOpen} onClose={handleEditDialogClose}>
        <DialogTitle>Edit Record</DialogTitle>
        <DialogContent>
          <TextField
            label="Currency"
            variant="outlined"
            value={editedCurrency}
            onChange={handleCurrencyChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Company Code"
            variant="outlined"
            value={editedCompanyCode}
            onChange={handleCompanyCodeChange}
            fullWidth
            margin="dense"
          />
          <TextField
            label="Distribution Channel"
            variant="outlined"
            value={editedDistributionChannel}
            onChange={handleDistributionChannelChange}
            fullWidth
            margin="dense"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleEditDialogClose}>Cancel</Button>
          <Button onClick={handleSaveEdit} color="primary" disabled={isSavingEdit}>
            {isSavingEdit ? <CircularProgress size={24} /> : 'Save'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default RecordsTable;
