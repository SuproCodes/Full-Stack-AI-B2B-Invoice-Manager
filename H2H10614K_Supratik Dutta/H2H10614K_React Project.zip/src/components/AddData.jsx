import React, { useState } from 'react';
import { Grid, TextField, Button } from '@mui/material';
import axios from 'axios';

const FormComponent = () => {
  const [customerOrderId, setCustomerOrderId] = useState('');
  const [salesOrg, setSalesOrg] = useState('');
  const [distributionChannel, setDistributionChannel] = useState('');
  const [customerNo, setCustomerNo] = useState('');
  const [companyCode, setCompanyCode] = useState('');
  const [orderCurrency, setOrderCurrency] = useState('');
  const [amountInUSD, setAmountInUSD] = useState('');
  const [orderCreationDate, setOrderCreationDate] = useState('');

  const handleFormSubmit = (event) => {
    event.preventDefault();

    // Prepare the data object to send to the backend
    const data = {
      customerOrderId,
      salesOrg,
      distributionChannel,
      customerNo,
      companyCode,
      orderCurrency,
      amountInUSD,
      orderCreationDate: new Date(orderCreationDate).toLocaleDateString('en-GB').split('/').join('-'),
    };

    console.log(data);

    // Send the data to the backend using Axios
    axios.post('http://localhost:8080/h2h11_milestone_11/DataLoadingServlet', data)
      .then((response) => {
        // Handle the response from the backend
        console.log('Response:', response.data);
        window.location.reload(); // Refresh the page
      })
      .catch((error) => {
        // Handle any network or other errors
        console.log('Error:', error);
      });
  };

  const handleFormCancel = () => {
    setCustomerOrderId('');
    setSalesOrg('');
    setDistributionChannel('');
    setCustomerNo('');
    setCompanyCode('');
    setOrderCurrency('');
    setAmountInUSD('');
    setOrderCreationDate('');
  };

  return (
    <form onSubmit={handleFormSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Customer Order ID"
            variant="outlined"
            fullWidth
            value={customerOrderId}
            onChange={(event) => setCustomerOrderId(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Sales Org"
            variant="outlined"
            fullWidth
            value={salesOrg}
            onChange={(event) => setSalesOrg(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Distribution Channel"
            variant="outlined"
            fullWidth
            value={distributionChannel}
            onChange={(event) => setDistributionChannel(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Customer No"
            variant="outlined"
            fullWidth
            value={customerNo}
            onChange={(event) => setCustomerNo(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Company Code"
            variant="outlined"
            fullWidth
            value={companyCode}
            onChange={(event) => setCompanyCode(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Order Currency"
            variant="outlined"
            fullWidth
            value={orderCurrency}
            onChange={(event) => setOrderCurrency(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Amount in USD"
            variant="outlined"
            fullWidth
            value={amountInUSD}
            onChange={(event) => setAmountInUSD(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Order Creation Date"
            variant="outlined"
            fullWidth
            type="date"
            value={orderCreationDate}
            onChange={(event) => setOrderCreationDate(event.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <Button type="submit" variant="contained" color="primary">
            Submit
          </Button>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Button variant="outlined" color="secondary" onClick={handleFormCancel}>
            Cancel
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default FormComponent;
