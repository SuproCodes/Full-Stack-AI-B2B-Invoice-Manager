// import React from 'react';
// import Button from '@mui/material/Button';

// const RefreshButton = () => {
//   const handleRefresh = () => {
//     window.location.reload(); // Reloads the page
//   };

//   return (
//     <Button variant="contained" onClick={handleRefresh}>
//       Refresh
//     </Button>
//   );
// };

// export default RefreshButton;
