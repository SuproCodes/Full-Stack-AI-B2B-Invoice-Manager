import React, { useState } from 'react';
import { Tabs, Tab, Typography, Box } from '@mui/material';
import InvoiceList from "./InvoiceList"
import FormComponent from './AddData';

const TabComponent = () => {
  const [currentTab, setCurrentTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
  };

  const generateRandomData = () => {
    // Generate random data here
    return Math.random().toString(36).substring(2, 15);
  };

  return (
    <div>
      <Tabs value={currentTab} onChange={handleTabChange} centered>
        <Tab label="HOME PAGE" />
        <Tab label="ADD DATA" />
        <Tab label="ANALYTICS VIEW" />
      </Tabs>

      <TabPanel value={currentTab} index={0}>
        <InvoiceList/>
      </TabPanel>

      <TabPanel value={currentTab} index={1}>
        <FormComponent/> 
      </TabPanel>

      <TabPanel value={currentTab} index={2}>
        <Typography variant="h6">Tab 3 Content</Typography>
        <Typography>{generateRandomData()}</Typography>
        <Typography>{generateRandomData()}</Typography>
        <Typography>{generateRandomData()}</Typography>
      </TabPanel>
    </div>
  );
};

const TabPanel = ({ value, index, children }) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
};

export default TabComponent;
